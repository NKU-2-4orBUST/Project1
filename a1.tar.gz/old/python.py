import subprocess, os,sys

def apache_install():    
    os.system('echo Installing Apache 2.4 and Mod_ssl.... | tee  -a /root/apache_install.log')# Inform User Download process is beginning
    os.system('yum -y install httpd >> /root/apache_install.log 2>&1')# Downloads apache sournce .gz
    os.system('yum -y install mod_ssl >> /root/apache_install.log 2>&1')# Downloads apache sournce .gz    
#os.system('echo Unzipping httpd-2.2.0.tar.gz | tee -a /root/apache_install.log')# Inform User unzip process is beginning
    #subprocess.run(['tar','-xzf','httpd-2.2.0.tar.gz'])#unzip apache 2.2 source files
    #os.system('echo Installing Apache Web Server 2.4... | tee -a /root/apache_install.log')## Inform User Apache Install process is beginning
    #os.chdir('./httpd-2.') #Change directorie to httpd-2.2.0
    #os.system('./configure --prefix=/usr/local/apache --enable-so --enable-mod_rewrite>> /root/apache_install.log 2>&1')#Installs Apache2.2 pt1/3
    #os.system('make >> /root/apache_install.log 2>&1')#Installs Apache2.2 pt2/3
    #os.system('make install >> /root/apache_install.log 2>&1')#Installs Apache2.2 pt3/3
    return

def apache_conf():
    os.system('echo Configuring Apache Webserver... | tee -a /root/apache_install.log') #Begin Apache Configuration
    os.chdir('/root')# Changes pythons directory back to root to copy config files 
    #os.system('\\cp  apxs /usr/local/apache/bin/ >> /root/apache_install.log')# Replace original apxs with known good apxs config
    #os.system('/usr/local/apache/bin/apxs -cia ./httpd-2.2.0/modules/mappers/mod_rewrite.c  >> /root/apache_install.log') #Activates mod_rewrite
    os.system('\\cp httpd.conf /etc/httpd/conf >> /root/apache_install.log') #Replaces apache config with know good config
    os.system('\\cp userdir.conf /etc/httpd/conf.d/ >> /root/apache_install.log')
    os.system('mkdir /etc/httpd/ssl')# Creates the ssl directory for Apache
    os.chdir('/etc/httpd/ssl')#Changes to SSL directory
    os.system('openssl genrsa -out 10_2_7_71_Group_2.key 1024 >> /root/apache_install.log 2>&1')
    os.system('openssl req -new -key 10_2_7_71_Group_2.key -subj "/C=US/ST=Kentucky/L=Highland Heights/O=NKU/CN=10-2-7-71-Group-2" -out 10_2_7_71_Group_2.csr')
    os.system('openssl req -new -newkey rsa:2048 -nodes -out 10_2_7_71_Group_2.csr -keyout 10_2_7_71_Group_2.key -subj "/C=US/ST=Kentucky/L=Highland Heights/O=NKU/OU=CIT/CN=cit470-001.hh.nku.edu" >> /root/apache_install.log 2>&1') #Creates SSL keys for Apache HTTPS 
    os.system('openssl x509 -req -days 365 -in 10_2_7_71_Group_2.csr -signkey 10_2_7_71_Group_2.key -out 10_2_7_71_Group_2.crt >> /root/ApacheInstallScriptLog 2>&1')# Creates SSL CRT file

    return
def firewall_conf():
    os.system('echo Configuring Firewall for Apache | tee -a /root/apache_install.log') #Begin Firewall Configuration
    os.system('sudo firewall-cmd --permanent --add-port=80/tcp >> /root/apache_install.log 2>&1') #Opens port 80 to tcp traffic
    os.system('sudo firewall-cmd --permanent --add-port=443/tcp >> /root/apache_install.log 2>&1') #Opens port 443 to tcp traffic
    os.system('sudo firewall-cmd --reload>> /root/apache_install.log 2>&1') #Reloads the firewall
    os.system('echo Waiting for firewall to reload && sleep 5 && Firewall reloaded')
    return

def _main_(): # Main function taht calls all functions and allows for easy diable for troubleshooting
    apache_install()
    apache_conf()
    firewall_conf()
    os.system('systemctl start httpd')#Starts Apache webserver 
_main_()
