import subprocess, os,sys

def apache_install():    
    os.system('echo Installing Apache 2.4 and Mod_ssl.... | tee  -a /root/apache_install.log')# Inform User Download process is beginning
    os.system('yum -y install httpd >> /root/apache_install.log 2>&1')# Downloads apache sournce .gz
    os.system('yum -y install mod_ssl >> /root/apache_install.log 2>&1')# Downloads apache sournce .gz    
    return

def apache_conf():
    os.system('echo Configuring Apache Webserver... | tee -a /root/apache_install.log') #Begin Apache Configuration
    os.chdir('/root')# Changes pythons directory back to root to copy config files 
    os.system('\\cp httpd.conf /etc/httpd/conf >> /root/apache_install.log') #Replaces apache config with know good config
    os.system('\\cp userdir.conf /etc/httpd/conf.d/ >> /root/apache_install.log')# Replaces userdir.conf with known good file
    os.system('mkdir /etc/httpd/ssl')# Creates the ssl directory for Apache
    os.chdir('/etc/httpd/ssl')#Changes to SSL directory
    os.system('openssl genrsa -out 10_2_7_71_Group_2.key 1024 >> /root/apache_install.log 2>&1')# Creates .key file for SSL 
    os.system('openssl req -new -key 10_2_7_71_Group_2.key -subj "/C=US/ST=Kentucky/L=Highland Heights/O=NKU/CN=10-2-7-71-Group-2" -out 10_2_7_71_Group_2.csr')# Creates .csr file for SSL
    os.system('openssl x509 -req -days 365 -in 10_2_7_71_Group_2.csr -signkey 10_2_7_71_Group_2.key -out 10_2_7_71_Group_2.crt >> /root/ApacheInstallScriptLog 2>&1')# Creates SSL CRT file
    os.system('setsebool -P httpd_enable_homedirs on')#Configuration needed to allow traffic with SElinux
    os.system('chcon -R -t httpd_sys_content_t /home/')#Configuration needed to allow traffic with SElinux
    os.system('chcon -R -t httpd_sys_rw_content_t /home/')#Configuration needed to allow traffic with SElinux
    return
def firewall_conf():
    os.system('echo Configuring Firewall for Apache | tee -a /root/apache_install.log') #Begin Firewall Configuration
    os.system('sudo firewall-cmd --permanent --add-port=80/tcp >> /root/apache_install.log 2>&1') #Opens port 80 to tcp traffic
    os.system('sudo firewall-cmd --permanent --add-port=443/tcp >> /root/apache_install.log 2>&1') #Opens port 443 to tcp traffic
    os.system('sudo firewall-cmd --reload>> /root/apache_install.log 2>&1') #Reloads the firewall
    os.system('echo Waiting for firewall to reload && sleep 5 && echo firewall reloaded')
    return

def _main_(): # Main function that calls all functions and allows for easy diable for troubleshooting
    apache_install()
    apache_conf()
    firewall_conf()
    os.system('systemctl start httpd')#Starts Apache webserver 
_main_()
